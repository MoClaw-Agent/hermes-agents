---
name: juritheque-scraper
description: JuriThèque legal corpus scraper and ADALA converter.
---

# JuriThèque Scraper

Standalone browser-driven scraper for https://juritheque.com/ (official Moroccan legal platform, 15,352 law URLs in sitemap).

## Architecture

- **Scraper**: `fetching/juritheque/scrape.py` — browser_exec-based, resumable JSONL output
- **Converter**: `fetching/juritheque/convert_to_adala.py` — transforms JuriThèque JSONs to ADALA-compatible structure
- **Docs**: `doc/JURITHEQUE_SCRAPER.md`

## Stable Configuration

```python
ScrapeConfig(
    request_delay=3.0,
    browser_wait=2.0,
    max_retries=3,
    batch_size=10,                # 0% failure rate; batch_size=20 → 30% failure
    reopen_browser_interval=10,   # resets stale tabs every 10 laws
    dismiss_consent=True,
)
```

**Critical**: batch_size must stay ≤10. Larger batches cause browser WebSocket instability.

## Output Structure

```
data/corpus/juritheque/<domain>/<lang>/<instrument>/<ref>.json
```

Fields: source_provider, source_url, title_fr, title_ar, reference, document_type, date, domain, language, pdf_url, source_link, external_links, summary, articles_cles, content_fr, content_ar, full_text, structure, _juritheque

## ADALA Format Conversion

```bash
venv/bin/python3 -m fetching.juritheque.convert_to_adala \
    --input data/corpus/juritheque \
    --output data/corpus/adala/json
```

Maps instrument_type → document_type, domain → collection_title. Builds structure[] with preamble + article tree. Preserves JuriThèque metadata in `_juritheque` sidecar.

## Quality Fixes Applied

1. Arabic domain detection via URL slug keywords (القانون, مرسوم, الإدارة)
2. Arabic title extraction (قانون رقم / مرسوم رقم / قرار)
3. Robust full-text button click (multi-variant: عرض النص / Lire le texte intégral)
4. Article-level bilingual split with paragraph fallback (>80 chars)
5. Website disclaimer strip (consent banner, footer)
6. Permissive external links (all non-CDN/non-font)
7. French quality-header strip (Texte brut extrait du PDF — qualité variable)

## Running the Scraper

```python
exec(open('fetching/juritheque/scrape.py').read())
stats = run_from_sitemap(
    sitemap_path='data/corpus/juritheque/sitemap.xml',
    output_base='data/corpus/juritheque',
    config=ScrapeConfig(...),
    start_index=<sitemap_position>,
    batch_size=10
)
```

Each law is written immediately; index is updated per domain/lang. Progress resumable via sitemap position lookup.

## Known Limitations

- 29% of pages have zero full_text (PDF-only/draft documents — source-side limitation)
- 11% of Arabic pages lack article markers (paragraph-level fallback handles some)
- "unknown" domain affects ~15% of files (Arabic URL slugs without domain keywords)
- Full 15,352-law scrape ≈ 7.5 days at batch_size=10
