---
name: mizan-legal-platform-debugging
description: "Debug Mizan legal search, citation, and ingestion pipelines."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [mizan, debugging, qdrant, adala, citations, retrieval, ingestion]
    related_skills: [systematic-debugging, ocr-and-documents]
---

# Mizan Legal Platform Debugging

## When to Use

- Search replies show "unknown" sources/citations
- Dense retrieval returns 0 results for valid queries
- Parser marks documents as failed with "zero article nodes"
- Citation verification fails or strips valid citations
- User reports ingestion or search quality issues

## Architecture Overview

**Retrieval pipeline** (API endpoint → response):
```
History Resolver (query/history_resolver.py) → EntityFrame {law_ids, domain, context_summary}
  → QU Pipeline (query/pipeline.py) → domain detection (English short form, e.g. 'commercial')
  → HybridRetriever.retrieve() → _retrieve_law() → _dense_sparse_fuse()
    → Dense: DualCollectionManager.search() → Qdrant query_points
    → Sparse: BM25S disk index (no Qdrant filters)
    → RRF fusion → enrich_sparse_hits() (payload backfill for sparse-only hits)
  → Reranker → _build_mizan_results() (DocumentChunk with merged metadata)
  → LLM reasoning → _resolve_citation_metadata() → build_ref_label()
```

**Key files**:
- `retrieval/hybrid/filters.py` — `build_qdrant_filter` (hybrid path filter builder)
- `retrieval/hybrid/hybrid_search.py` — `_retrieve_law`, `_retrieve_hybrid`
- `retrieval/hybrid/fusion.py` — `_dense_sparse_fuse` (dense+sparse RRF fusion)
- `fetching/pipeline_base/structure.py` — `build_tree`, `is_article_line`, `_is_french_article_line`
- `api/routes/search.py` — `/search` endpoint, hydrate_citations_from_results
- `api/routes/search_pipeline/` — coordinator, retrieval, reasoning, verification phases
- `ingestion/stages/chunk/_engine.py` — chunk payload builder (Qdrant payload population)
- `ontology/domain_map.json` — canonical domain map (French keys + qdnt_keys)
- `ontology/domain_normalizer.py` — normalize_domain(), canonical_to_qdnt()

**Citation rendering**:
- `reasoning/engine/helpers.py` — `build_ref_label`, `build_citation_meta_from_res`, `hydrate_citations_from_results`
- `reasoning/engine/engine.py` — `_build_prompt` (context header), `_resolve_citation_metadata`
- `reasoning/citation_gate.py` — citation gate marker stripping

**ADALA parser**:
- `fetching/adala/parser/pipeline.py` — main ADALA parsing pipeline
- `fetching/pipeline_base/structure.py` — `build_tree` (hierarchy), `is_article_line` (Arabic), `_is_french_article_line` (French)
- `ingestion/pre_converters/law.py` — law route converter

**Qdrant payload storage**:
- `retrieval/qdnt/manager.py` — QdrantManager, get_qdrant_manager
- `retrieval/dual_collection/manager.py` — DualCollectionManager (routes across 3 collections)
- `retrieval/hybrid/filters.py` — `fetch_missing_payloads` (payload backfill for sparse-only hits)

## Pitfall: Domain Normalization Gap Kills Dense Retrieval

The Query Understanding pipeline detects domains as English short forms (e.g. `commercial`). Qdrant payloads use canonical French keys (e.g. `droit_commercial`). Two separate filter-building paths exist:

| Path | File | Normalizes domain? |
|------|------|--------------------|
| Dense engine | `retrieval/dense/_engine.py:_build_qdrant_filter` | YES — calls normalize_domain() |
| Hybrid path | `retrieval/hybrid/filters.py:build_qdrant_filter` | NO (was missing) |

The hybrid path's filter is what gets passed to Qdrant for actual searches. Without normalization, English values like `commercial` match zero chunks → dense returns 0 → all results from BM25S sparse → fewer semantic signals → weak citations.

**Detection**: Check mizan.log for `[HYBRID] dense: 0 results` on queries that should match known content. Verify the actual Qdrant filter being built by inspecting the FieldCondition match values.

## Pitfall: Qdrant Timeout in Cross-Document Reference Expansion

The hybrid retrieval pipeline calls `engine.dense.expand_top_k()` during fusion. This method internally calls `_expand_cross_document_refs()` → `_resolve_canonical_ref()` → `dcm.scroll_all()`, which can raise `qdrant_client.http.exceptions.ResponseHandlingException` when the Qdrant server times out.

The Qdrant log will show:
```
ERROR qdrant::actix::helpers: Error processing request: Service internal error: 1 of 1 read operations failed:
  Timeout error: Operation 'scroll_by_id' timed out after 60s
```

This exception is NOT caught by the existing `suppress_and_log` in `retrieval/hybrid/fusion.py` (which only catches ConnectionError, TimeoutError, RuntimeError, OSError) or the narrow except in `_resolve_canonical_ref`. The result is an unhandled 500 error that crashes the entire search request.

**Detection**: Search log shows `Dense retrieval failed in parallel path: ... timed out` followed by a 500 response.

**Fix pattern**: Expand the exception tuples at both layers:
- `retrieval/dense/_engine.py:_resolve_canonical_ref` — add ConnectionError, TimeoutError, and a catch-all except Exception for Qdrant client exceptions
- `retrieval/hybrid/fusion.py:expand_top_k` caller — wrap in broad try/except Exception so any Qdrant timeout degrades gracefully (skips cross-doc expansion) instead of crashing

## Pitfall: Temporal Filter Config Leaking into MatchValue

When the hierarchical retriever passes a `filters` dict containing a `temporal` key (e.g. `{"as_of": "2026-05-07", "include_historical": false}`), the filter builder must skip non-pod keys before iterating dict values. If the temporal config dict leaks into a `MatchValue`, Qdrant's Pydantic validation rejects it with:
```
value.bool / value.int / value.str — Input should be a valid boolean/integer/string
```

The error shows a full config dict `{"as_of": "2026-05-07", ...}` as the `input_value` instead of a scalar.

**Detection**: Log shows `[HYBRID] Dense retrieval failed in parallel path: N validation errors for MatchValue`.

**Fix pattern**: In `build_qdrant_filter`, ensure `temporal` and other config keys are consumed as intentional flags (e.g. `start_date`, `end_date` extraction) and NOT passed as raw dict values to Qdrent `MatchValue` constructors.

## Pitfall: Page-Filtering Regex Missing Article Header Variants

`fetching/adala/parser/pipeline.py:_is_operational_structure_page` decides which pages participate in structure parsing. Its regex for French article headers must include ALL variants recognized by `is_article_line` and `_is_french_article_line` — `premier|1er|unique|preliminary|[0-9]+`.

If a variant is missing, PDFs whose only article header uses that variant (e.g. "Article Unique") get filtered out → `build_tree` sees no articles → `count_articles` returns 0 → parser marks file as failed ("substantial text but zero article nodes").

**Symptom**: Files in `data/logs/adala_parser_failed.jsonl` with that exact error.

**Fix pattern**: Keep the filter regex alternation in sync with the article-detection regex. Audit includes `unique` and `preliminary` even though they map to `art_num=None` (these are real article nodes — they just have no sequential number).

## Pitfall: SGG BO Parser Quality Gap vs ADALA

The SGG parser (`fetching/sgg/parser/pipeline.py`) has a fundamentally different code path from ADALA for BO containers:

- **ADALA**: Calls `build_tree(pages)` on every single PDF, producing a full hierarchy tree with article nodes.
- **SGG BO containers**: Parse TOC into metadata-only entries, then count articles via Arabic-only regex (`re.findall(r"(?:المادة|الماده|اده|الفصل)\s+\d+", ...)`).

This means French BO documents (which use "Article 1", "Article Unique", etc.) are never properly parsed. The article count is always 0 for French docs → validation fails ("substantial text but zero article nodes") → file gets marked as failed.

**Detection**: Compare `ada_parser_failed.jsonl` with SGG BO JSONs — French BO docs show `structure: []` and `num_articles_detected: 0`.

**Fix pattern**: In `_build_bo_container_output()` and `_build_individual_doc_json()`, call `build_tree([doc_text], document_language=language)` + `count_articles(structure)` — the same approach ADALA uses. Also add `source_provider: "sgg"` and `source_url` from sidecar data (both were `None` in the output JSONs).

## Pitfall: API Quota Exhaustion Returns Silent Empty

When the configured LLM provider hits its quota (e.g. OpenRouter returns `anonymous_quota_exceeded`), the `/search` endpoint returns HTTP 200 with:
- `answer`: empty string or "No output from model."
- `confidence_score`: 0
- `citations`: []
- `timing.total_ms`: near-zero

This is a silent failure — the user sees a blank response with no error indication. The pipeline does not detect quota exhaustion or fall back to a secondary model.

**Detection**: Check `data/logs/mizan.log` for `[LLM reasoning] Empty response from LLM` or `[ERROR] Quota exceeded`. Compare API response `confidence_score` against a threshold (< 0.1 = likely empty).

**Fix pattern**: When the primary LLM provider returns quota errors, the engine should auto-fallback to the next configured provider (e.g. Ollama local → OpenRouter → NVIDIA). If all providers are exhausted, return a structured error in the response payload rather than an empty 200.

## Pitfall: Dense Returns 0 Due to Domain Misclassification (Data Quality)

When QU detects `domain=commercial` but Qdrant payloads contain `domain=droit_civil` (wrong classification at ingestion), domain normalization (`commercial` → `droit_commercial`) still yields 0 matches. The dense engine returns 0, sparse returns 20, and the pipeline proceeds with sparse-only results.

This is NOT a filter bug — it is a data quality issue where documents were classified under the wrong domain key. The filter is correct; the payload is wrong.

**Detection**: Run a 5-query audit against known documents. If dense always returns 0 while sparse retrieves the correct ref, inspect the Qdrant payload's `domain` field vs the query's detected domain.

**Fix pattern**: Two tracks:
1. (Short-term) Make domain a soft filter — use it as a score boost rather than a hard exclusion, so misclassified docs still appear.
2. (Long-term) Re-ingest affected documents with corrected domain classification.

## Followup Context Resolution (History Resolver)

The pipeline resolves followup queries against prior conversation context so that "et la procédure ?" retrieves within the referenced legal scope instead of standalone.

**Module**: `query/history_resolver.py`
- `EntityFrame` dataclass: `resolved_query`, `law_ids`, `domain`, `context_summary`
- `resolve_history(query, history)` → `EntityFrame`
- Deterministic regex-based extraction (no LLM call at this layer)

**Law number patterns** (French + Arabic):
- `n° 70.03`, `loi n° 70.03`, `loi 70.03`, `dahir 1-25-73`
- `قانون رقم 65-99`, `مرسوم رقم 2-26-14`, `قرار وزاري رقم 2288-08`
- Deduped preserving order

**Domain inference**: Keyword-based (`famille` → Family Law, `travail` → Labor Law, `pénal` → Criminal Law, etc.)

**Followup detection**: Pronoun patterns (`cette loi`, `ce code`, `cette dernière`, `هذا القانون`) or short queries (≤4 words, no digits).

**Integration points**:
- `api/routes/search_pipeline/retrieval.py:_run_query_understanding` — calls `resolve_history()` before QU, passes `entity_frame.resolved_query` to QU pipeline, attaches `_entity_frame` to qu_result
- `api/routes/search_pipeline/reasoning.py:_run_llm_reasoning` — injects `context_summary` as system message into enriched history for the LLM prompt

**Tests**: `tests/test_history_resolver.py` — 20 tests covering EntityFrame construction, law extraction, domain inference, pronoun resolution, Arabic Unicode, malformed history edge cases.

**SOTA behavior**: When history is present and law IDs are resolved, retrieval is scoped to the referenced legal context. When no history or no law IDs detected, the query passes through unchanged (backward compatible).

## Corpus QA Generation and 5-Query Audit

When evaluating retrieval quality, use this repeatable pattern:

1. **Generate Q&A pairs from ingested documents**: Read `sqlite3 mizan.db` for documents with non-null `title` and `ref`. Generate type-aware French questions based on `document_type` (dahir → "Que promulgue le Dahir...", loi → "Que contient la Loi...", décret → "Que contient le Décret...", arrêté → "Que stipule l'Arrêté..."). Write to `data/corpus/adala/french_qa_50.json`.

2. **Run audit script**: For each question, execute QU → retrieval → LLM reasoning in-process (skip reranker on CPU). Check whether the expected ref appears in citations or answer text. Pass criterion: `ref_in_citations OR (matched_title_tokens >= 3 AND ref_in_answer)`.

3. **Score**: Report pass/total. A pass rate < 50% indicates retrieval degradation, not Q&A generation failure.

The audit script template lives at `scripts/run_5query_audit.py` and can be regenerated for different domains or languages.

## Evaluating Potential Data Sources for Scraping

When assessing a website as a potential corpus source:

1. **Check robots.txt** — is scraping allowed for all user-agents?
2. **Check terms of use** — many sites have permissive robots.txt but explicitly prohibit automated extraction in their ToS. Example: `huquqai.ma` has `Allow: /` for all user-agents but its `/use-terms` page states:
   > يُحظر: (أ) الاستخراج الآلي (scraping) للخدمة دون إذن
   > ("Prohibited: Automated extraction (scraping) of the service without permission")
3. **Check for sitemap.xml** — exists on juritheque.com with 6,774 law URLs
4. **Check for PDF download patterns** — juritheque.com hosts PDFs at `pdfs.juritheque.com`; original SGG/ADALA source links may also be present
5. **Report both signals clearly** — robots.txt permissive + ToS prohibitive = seek permission via contact email, do not scrape.

### Supabase-Backed Sites

Many modern legal platforms use Supabase as their backend. The URL pattern is `https://<project-ref>.supabase.co`. To check for API access:

1. **Find the project ref** — look in page source or JS bundles for `https://<ref>.supabase.co`
2. **Check for anon key** — Supabase anon keys are JWTs (`eyJ...`). They may be in:
   - Inline `<script>` tags with `supabase` in the src
   - JS bundles (search for `eyJ[A-Za-z0-9_=]+\.[A-Za-z0-9_=]+\.[A-Za-z0-9_-]+`)
   - Build-time env vars (not in static files — requires runtime interception)
3. **Test the REST API** — `curl https://<ref>.supabase.co/rest/v1/ -H "apikey: <key>"` — if the key works, you get JSON responses instead of HTML
4. **If no key found** — fall back to browser-based scraping (same pattern as JuriThèque)

### JuriThèque (juritheque.com)

Moroccan legal database with 7,000+ texts across 17 domains. Backend: Supabase (`bmargdbbcnhkrjeidmvh.supabase.co`).

**URL structure:**
- `/base` — database with filters (type, domain, status, language)
- `/domaine/<slug>` — domain pages (e.g. `/domaine/droit-civil`)
- `/loi/<slug>` — individual law pages (e.g. `/loi/loi-66-23-organisation-profession-avocat`)

**Page content:** Bilingual title, reference, date, domain, article count, source (SGG/BO), AI summary (FR+AR), "Articles clés" excerpts, full text viewer.

**Scraping assessment:** robots.txt allows all public pages. Legal texts are public domain. No explicit scraping prohibition in mentions-legales. Anon key not in static bundle (build-time env injection) — browser scraping required.

**Advantage over other sources:** Structured text pages (not PDF-only), domain classification, bilingual on same page, article-level excerpts.

## JuriThèque Scraping Workflow

JuriThèque (`juritheque.com`) is a bilingual Moroccan legal database with 7,000+ texts across 17 domains. Backend: Supabase. Legal texts are public domain (official Moroccan legislation). robots.txt allows all public pages. No explicit scraping prohibition in mentions-legales.

### Discovery Checklist

1. Check `robots.txt` — allows all public pages (`/base`, `/domaines`, `/domaine/`, `/loi/`, `/videos`, `/assistant`)
2. Check `/mentions-legales` — no scraping prohibition; legal texts are public domain
3. Check for `sitemap.xml` — present, ~6,774 law URLs under `/loi/<slug>`
4. Check page structure — client-side rendered, requires browser tool
5. Check for Supabase anon key — not in static bundle (build-time env injection), browser scraping required

### Scraper Architecture

The standalone scraper lives at `fetching/juritheque/scrape.py`. Key properties:
- **Resumable**: skips law IDs already present in output
- **Browser-dependent**: uses `browser_exec` auto-imported helpers (new_tab, wait_for_load, js)
- **Output format**: JSON files organized by domain/language/instrument_type

### Folder Structure

```
data/corpus/juritheque/<domain>/<lang>/<instrument_type>/<reference>.json
```

Example: `data/corpus/juritheque/droit_du_travail/ar/dahir/dahir_1_03_194.json`

### Metadata Extracted

- `title_fr`, `title_ar` — bilingual titles
- `reference` — law number (e.g. `1-03-194`)
- `instrument_type` — dahir, decree, law, arrete, circulaire, ordonnance, convention, treaty, decision, avis, code
- `domain` — 17 legal domains (normalized to ASCII slugs)
- `language` — `ar` or `fr` (via script detection)
- `date`, `article_count`
- `source_authority` (e.g. Bulletin Officiel)
- `bo_number`
- `pdf_url` — JuriThèque-hosted PDF
- `source_link` — "Visiter la source" link (original government portal)
- `external_links` — meaningful SGG/ADALA/government links (CDNs/fonts filtered)
- `full_text` — complete law text from "Texte brut" section
- `summary` — AI-generated synthesis
- `articles_cles` — key article excerpts

### Running

The scraper must be run inside a `browser_exec` call (not standalone Python), because the browser helpers are auto-imported into that context only:

```python
exec(open("fetching/juritheque/scrape.py").read())
run_from_sitemap("/tmp/juritheque_sitemap.xml", "data/corpus/juritheque", limit=100)
```

### Sitemap Parsing

The sitemap XML uses `<loc>` tags inside a namespace. Use `{http://www.sitemaps.org/schemas/sitemap/0.9}loc` in ElementTree, or regex `/loi/([^<]+)` as fallback.

## Corpus QA 5-Query Audit

When evaluating retrieval quality:

1. **Generate Q&A from ingested docs**: Query `sqlite3 mizan.db` for documents with non-null `title` and `ref`. Generate type-aware French questions (dahir → "Que promulgue...", loi → "Que contient la Loi...", etc.). Write to `data/corpus/adala/french_qa_50.json`.

2. **Run audit**: Execute QU → retrieval → LLM reasoning in-process. Check whether the expected ref appears in citations or answer text.

3. **Pass criterion**: `ref_in_citations OR (matched_title_tokens >= 3 AND ref_in_answer)`

If the LLM reasoning step is unavailable (quota exceeded or local model too slow), the retrieval-only check is still valid: verify the expected ref appears in the top-3 candidates from BM25S sparse retrieval.

The audit script template lives at `scripts/run_5query_audit.py`.

## Read-Only Audit Tool

When asked to trace or audit behavior without changing code, use this pattern in `execute_code`:

```python
import sys
sys.path.insert(0, '/repo/path')
sys.path.insert(0, '/repo/path/venv/lib/python3.11/site-packages')

from retrieval.qdrant import get_qdrant_manager
qm = get_qdrant_manager()

# Direct Qdrant scroll — bypasses all filters and pipeline logic
records, _ = qm.client.scroll(
    collection_name='mizan_law',
    scroll_filter=...,
    limit=N,
    with_payload=True,
    with_vectors=False,
)
for rec in records:
    print(rec.payload)
```

This verifies ground-truth Qdrant payloads without touching the retrieval pipeline.

## Pitfall: Identity Boost Reranking Before Top-N Cut

When a query names a legal reference verbatim ("dahir n° 1-25-54") or echoes distinctive title tokens ("code des Habous"), the target document's chunks may sit at RRF rank 30-50 and get silently dropped by the Stage-1 heuristic top-N cut (`RERANKER_HEURISTIC_TOP_N`) before the CrossEncoder ever sees them. The LLM then answers from the wrong instrument entirely.

**Detection**: Run a 5-query audit. If the expected document's chunks are at RRF rank > 10 despite being fully indexed, the top-N cut is the culprit.

**Fix pattern**: Apply identity boosts (`_apply_identity_boosts()`) on ALL candidates BEFORE the top-N cut. Fold bounded boosts into `_heuristic_score` for:
- Exact reference match (query ref equals payload `doc_ref`/`short_name`/`canonical_id`) — default 0.15
- Partial match (query ref is a leading-segment prefix of a longer doc ref) — default 0.075
- Distinctive title-token overlap (≥3 shared tokens, length ≥5, boilerplate excluded) — default 0.05
- Date identity reinforcement (printed consolidation date matches query date) — half the title boost

Boosts are capped at ~0.15 (≈ one legal-rank step) so a boosted exact ref outranks hierarchy-only peers without flattening CrossEncoder relevance. Gated by `RERANKER_IDENTITY_BOOST_ENABLED` (default `true`).

## Pitfall: article_number Is int in Qdrant Payloads

The hierarchical retriever's `stage2_article_targeting` calls `.lower()` on `article_number` from Qdrant payloads. Production data stores this field as `int` (not `str`), causing `AttributeError: 'int' object has no attribute 'lower'`.

**Detection**: 500 error in hierarchical retrieval with the above traceback.

**Fix pattern**: Always coerce to `str` before string operations: `str(p.get("article_number")) or "".lower()`. Verify payload types with a direct Qdrant scroll before assuming string fields.

## Pitfall: Browser Helpers Are Not Importable

The `browser_exec` tool auto-imports helpers (`new_tab`, `wait_for_load`, `js`, etc.) into its own namespace. These are NOT available when imported from a Python module — even if the module is exec'd inside `browser_exec`.

**Wrong** (fails with `NameError: name 'new_tab' is not defined`):
```python
# In a separate .py file imported by browser_exec
class Scraper:
    def scrape_law(self, law_id):
        new_tab(url)  # NameError!
```

**Right** (pass browser helpers as args or closure):
```python
# Define scraper to accept helpers, or inline all browser calls directly
# in the browser_exec code block without indirection through modules.
def scrape_law(browser, law_id):
    browser.new_tab(url)
    browser.wait_for_load()
```

**Implication**: For browser automation tasks, write all browser interactions directly in the `browser_exec` code block. Do not abstract them into imported modules unless you pass the browser helpers as arguments.

## Log Files

- `data/logs/mizan.log` — main server log (pipeline stages, timers)
- `data/logs/mizn.json.log` — structured JSON log (if configured)
- `data/logs/adala_parser.log` — ADALA parser log (article counts, failures)
- `data/logs/adala_parser_failed.jsonl` — failure records
- `data/logs/adala_crawler.log` — crawler log
- `data/logs/adala_parser_state.json` — parser state
- `data/index/bm25s/corpus.jsonl` — BM25S index corpus IDs

## Environment Notes

- Python: 3.12.3 (use python3, not python)
- venv: `venv/lib/python3.11/site-packages`
- Qdrant: DualIndex mode (mizan_law, mizan_case, mizan_bo collections)
- LLM: Configured via .env (liquid/lfm-2.5-2.6b:free observed)
- Shell: PROMPT_COMMAND hook may break terminal calls — use execute_code
- Freebuff: CodebuffAI CLI (`npx freebuff`), sessions in `~/.config/manicode/`
