---
name: legal-corpus-pipeline
description: "Build Mizan legal-corpus scrapers and RAG providers."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [rag, corpus, scraper, legal, pipeline, browser-exec, mizan]
    related_skills: [test-driven-development]
---

# Legal Corpus Pipeline

## Overview

Class of work: evaluate a legal provider website, build a standalone scraper, test iteratively, dispatch to background, and update the rollout tracker so Mizan can corpus-compare across ADALA / SGG / JuriThèque at ingest time.

Active scrapers: `fetching/adala/`, `fetching/sgg/`, `fetching/dgssi/`, `fetching/juritheque/` (standalone). A huquqai scraper does NOT yet exist — the sitemap is available but no `fetching/huquqai/` module has been built.

The deliverable is a working scraper plus a committed rollout-plan entry. A partial submission (like "sitemap downloaded but scraper untested") is committed tech debt.

## Cross-Reference Ingestion

When ingesting legal cross-reference relations (e.g., REPEALS, MODIFIES from a provider's `legal_relations` table), the endpoint laws MUST already exist in Mizan's `documents` table for the edges to resolve. Relations reference source/target law IDs; these map to Mizan doc_ids via the `ref` column in `documents`. If the relation endpoints are not yet ingested, the edges cannot be inserted.

**Workflow:** Ingest the law corpus first → then ingest cross-references. If cross-references are fetched before the laws, store them in a staging table keyed by provider law ID and resolve during ingestion.

## Always-On Rules

1. **Test before Dispatch** — never dispatch a background batch run before at least one local test against the real site. Validate that the target URL renders and the scraper captures the fields you need.
2. **Code + rollout plan commit together** — when code changes, update the rollout plan (`ROLLOUT_MASTER_PLAN.md` or equivalent) in the same commit.
3. **Reference parse from title area only** — scanning the first ~500 chars of page text for a numeric reference prevents body dates and related-law card numbers from being picked as the primary reference.
4. **Bilingual split only when both languages are significant** — `content_fr` / `content_ar` fields are set only when BOTH are non-empty. Monolingual content stays in `full_text` only.
5. **Website disclaimer ≠ law disclaimer** — strip cookie-consent banners and site footer descriptions, NOT law-text metadata embedded in the posts themselves.
6. **Background daemon verification** — always confirm the subagent is live (via `delegate_task action=list` or tailing the live transcript) before declaring a dispatch success.
7. **Check for existing scraper first** — before building a new provider scraper, check `fetching/<provider>/scrape.py` and the terminal session map. The user may reference a scraper that already exists under a different name.
8. **Always set `workdir` on terminal() calls** — the terminal daemon initializes a stale cwd from a previous session. Every `terminal()` call MUST pass `workdir=/home/mohammed/Mizan` or the relevant project root. The shell-init `cd` failure is environmental noise, not a blocker — work around it, don't fight it.
9. **Don't chase unrelated local processes** — when the user asks about a hermes terminal session, look at `terminal-sessions/` metadata and `ps aux`. Do NOT start investigating freebuff, manicode, or other unrelated local services unless the user explicitly named them.
10. **API-first scraping** — before building a browser scraper, check if the site uses a backend API (Supabase, REST, GraphQL). The JS bundle often contains API keys and endpoint URLs. Direct API access is 10-100x faster than browser scraping and avoids WebSocket instability entirely. Look for `createClient(` patterns, `supabase` references, and `from("table_name")` calls in the JS bundle.
11. **Memory-efficient batch processing** — for large datasets (>1000 records), NEVER accumulate all records in memory. Process one batch at a time, save to disk, then fetch the next batch. Use `del batch` to explicitly free memory between iterations.
12. **Resume via progress file** — for long-running scrapes, persist processed IDs to a JSON progress file after each batch. On restart, load the progress file and skip already-processed IDs. This makes scrapes resumable across subagent timeouts and interruptions.
13. **Subagent timeout reality** — subagents exit after ~5 minutes. For long-running tasks, the script itself must be resilient (progress file, batch processing, resume support). Don't rely on the subagent to iterate — rely on the script's own loop.

## Workflow

### Phase 1 — Provider Evaluation

1. **Check robots.txt and terms of use** — a public-domain platform with no specific prohibition is a clean target.
2. **Explore content via `browser_exec`** — the JS-rendered SPA requires a real browser.
3. **Download the sitemap** — typically 5-10 MB XML. Cache it both for the scraper and for later delta comparison.
4. **Classify document types** — Dahir, Loi, Décret, Arrêté, Circulaire, Ordonnance — one subfolder per type.

### Phase 2 — Scraper Construction

1. **Architecture** — `fetching/<provider>/scrape.py` as a standalone module runnable from `browser_exec` context. The browser helpers (`new_tab`, `wait_for_load`, `js`) are auto-imported into the browser_exec namespace only; importing them elsewhere fails.
2. **Metadata extraction** — always include: `reference`, `title_fr`, `title_ar` (where available), `instrument_type`, `domain`, `language`, `date`, `article_count`, `pdf_url`, `source_link`.
3. **Content expansion** — many JS-rendered pages hide the full law text behind a button (JuriThèque uses `عرض النص` / `Lire le texte intégral`). The scraper MUST click the expand button before reading `innerText`. `el.click()` is primary; `dispatchEvent` is fallback.
4. **Bilingual split** — line-by-line script detection with a sliding-window gap tolerance captures Arabic blocks even when digits and Latin citations are interspersed. Merge back to `full_text` when only one language is significant.
5. **Reference detection** — first 500 chars only. Use instrument-keyword-aware patterns (e.g. `Loi n° <digits>` not `\d+ anywhere`).
6. **Index file per (domain, language) pair** — `<domain>/<lang>/index.json` stores a flat list of {reference, instrument_type, title_fr, title_ar, date, source_url, file_path} for cross-provider comparison.
7. **Politeness and resilience** — `request_delay` >= 3s, `max_retries` >= 3, periodic browser reopen (every ~50 URLs) to prevent stale-tab leaks.

### Phase 3 — Iterative Debug Cycle

1. **Test locally** before dispatching full batch. Use `browser_exec` with the module loaded via `exec(open(...).read())`.
2. **If a page fails**, inspect the page structure live: what buttons exist, what the first 500 chars contain, whether article markers are present.
3. **Patch, re-test, commit with rollout update.**
4. **Don't loop patches** — if 3 consecutive patches yield no behavior change, stop and read the file fresh before the next edit.

### Phase 4 — Background Dispatch

1. **Interactive batch size: 10 URLs** — with 3s delays + browser navigate/read per URL, 10 URLs takes ~60-90s, safely within the browser_exec 300s timeout. Batch size 40 (the old guidance) ALWAYS times out and forces a restart. Use `batch_size=10` for interactive runs.
2. **Background dispatch for large scrapes** — for anything >50 URLs, use `delegate_task` to run the full scraper in a background subagent. The subagent has its own browser context and can run the full sitemap to completion without the 300s constraint.
3. **Resumable loop** — pass `start_index` from the previous batch's stats. The scraper re-reads the sitemap and skips already-indexed laws.
4. **Verify daemon** — confirm the background subagent is live (poll list or tail transcript) before declaring progress.
5. **Commit code + update rollout** after each feature-complete batch.
6. **Wipe-and-restart with explicit user confirmation** — `data/corpus/<provider>` deletion is irreversible. Always confirm before `rm -rf` on corpus data, even if the user's intent seems clear from context.

### Phase 5 — Rollout Tracking

- **ROLLOUT_MASTER_PLAN.md** — one section per data provider. Mark implementation status, known limitations, cross-provider comparison.
- **CHANGELOG.md** — every code change lands here.

## References

- `references/browser-exec-scraper.md` — browser_exec context patterns, auto-imported helpers, pitfalls when running browser scrapers in subagent contexts.
- `references/api-first-scraping.md` — check for backend APIs (Supabase REST) before building browser scrapers; memory-efficient batch processing and resume patterns.
