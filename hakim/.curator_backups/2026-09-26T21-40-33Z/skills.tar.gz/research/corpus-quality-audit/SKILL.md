---
name: corpus-quality-audit
description: "Audit and repair ingested legal corpus JSON files."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [corpus, quality, audit, legal, arabic, adala, ocr, json]
    related_skills: [legal-corpus-pipeline, ocr-and-documents]
---

# Corpus Quality Audit & Repair

## Overview

Class of work: after a legal corpus has been ingested (scraped + parsed + stored as JSON), audit the JSON artifacts for quality defects and repair them in place. This is distinct from building the scraper (see `legal-corpus-pipeline`) — this is post-ingestion quality assurance.

Applies to: any ingested legal corpus stored as structured JSON (ADALA, SGG, DGSSI, JuriThèque, huquqai — any provider whose output is JSON documents with a `structure` tree and `page_texts_sample`).

## Always-On Rules

1. **Audit before repair** — always run a full statistical audit of the corpus BEFORE writing any repair code. Know the scope: total files, document type distribution, extraction mode distribution, article count distribution, empty section count. Repair without audit leads to wrong fixes.
2. **Distinguish defects from legitimate variation** — not every "0 articles" file is broken. Draft finance laws (مشروع قانون المالية) organized by parts/titles/books, and organizational decrees without numbered articles, are structurally valid without article nodes. Audit the FILE CONTENT before classifying as defect.
3. **Repair in place, preserve provenance** — fix the existing JSON files directly. Do NOT rebuild from raw PDFs unless the raw PDF itself is corrupt. The parsed JSON carries metadata (timestamp, extraction_mode, source_url) that would be lost on re-parse.
4. **Garbled OCR headers are a masthead issue, not a content issue** — when the official journal masthead (`الجريدة الرسمية العدد NNNN`) is garbled but the body text is clean, the fix is a targeted masthead repair, NOT a full re-OCR. Re-OCR of a document with clean body text wastes compute and risks introducing new errors.
5. **Empty sections are a parser tree issue, not missing content** — when sections have titles but no content, the content is usually in an adjacent sibling. The fix is tree surgery (merge title into next sibling's content), not data recovery.
6. **Add metadata flags, don't just fix** — when repairing, also add explicit flags (e.g. `has_article_structure`) so downstream consumers (search, RAG) know what to expect. A flag is better than implicit behavior.
7. **Work from the JSON, not the PDF** — the JSON is the parsed artifact. When auditing quality, work from the JSON files in `data/corpus/<provider>/json/<lang>/`. The raw PDFs in `data/corpus/<provider>/raw/` are the source; only revisit them if the JSON defect traces to PDF-level corruption.
8. **When fixing a parser bug, patch the parser AND re-parse** — in-place JSON repair fixes the current corpus, but a future re-parse re-introduces the defect. For a complete valid corpus, fix both: (a) the JSON files in place, and (b) the parser code so re-parses produce clean output. Then re-parse. If only the current corpus needs to be clean, in-place repair suffices.
9. **Verify after repair** — run the same audit metrics after repair to confirm the fix worked. Zero defects should be verified, not assumed.

## Patch the Parser When Fixes Must Survive Re-Parse

In-place JSON repair fixes the existing corpus, but a future re-parse will re-introduce the defect if the parser itself is not fixed. For a complete valid corpus, fix BOTH:

1. **Fix the JSON in place** — repair the existing 2,832 files (Step 1-3 above).
2. **Fix the parser** — so any future re-parse produces clean output:
   - **Masthead repair:** add the masthead repair as a post-extraction step in `pipeline.py` (after pages are extracted, before `build_tree`). Collect the async generator into a list first — the masthead repair loop needs random access and the generator can only be consumed once.
   - **Empty section merging:** add the merge logic to `build_tree()` in `structure.py` so it runs during every parse. Use a pending-titles accumulator that chains consecutive empty containers (`title1; title2: next_content`) rather than just merging the immediately preceding one — alternating empty/non-empty patterns (e.g. tariff grids) need the accumulator.
   - **Metadata flag:** add `has_article_structure` to the output dict in `pipeline.py` so downstream search/RAG knows whether article-level chunking is available.
   - **False-positive container detection:** tighten `_container_hit()` so body text that merely mentions a section keyword (e.g. `-كلغ 200 من القسم الأول...`) is not promoted to a container node. Use anchored regex first (`_CONTAINER_HEAD_RE.match(line)`), then fall back to fuzzy matching only with a narrow position window (pos ≤ 5) — body-text mentions have the keyword far from line start.
3. **Re-parse the corpus** with the fixed parser to produce a clean corpus from source.

**Decision rule:** if the user wants a complete valid corpus with no errors, fix the parser AND re-parse. If the user only needs the current corpus clean, in-place JSON repair is sufficient.

## When NOT to Repair

- **0-article files that are draft finance laws (مشروع قانون المالية) or organizational decrees** — these are structurally valid without numbered articles. Check `full_text_in_cache` and structure content before classifying.
- **Documents where the body text is also garbled** — masthead repair alone is insufficient; full re-OCR is needed.
- **Empty sections that are genuinely empty by design** — investigate before merging.

## Workflow

### Phase 1 — Full Corpus Audit

Audit the entire corpus statistically before targeting specific files.

```python
import json
from pathlib import Path
from collections import Counter

corpus_dir = Path("/home/mohammed/Mizan/data/corpus/adala/json/ar")

total_files = 0
doc_type_counter = Counter()
extraction_mode_counter = Counter()
articles_counter = Counter()
empty_sections = 0

for json_file in corpus_dir.rglob("*.json"):
    total_files += 1
    with open(json_file, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    doc_type_counter[data.get('document_type', 'unknown')] += 1
    extraction_mode_counter[data.get('extraction_mode', 'unknown')] += 1
    
    num_articles = data.get('num_articles_detected')
    if num_articles is not None:
        articles_counter[num_articles] += 1
    
    structure = data.get('structure', [])
    if structure:
        for item in structure:
            if item.get('type') == 'section':
                content = item.get('content', '')
                if not content or not content.strip():
                    empty_sections += 1

print(f"Total: {total_files}")
print(f"Doc types: {doc_type_counter.most_common()}")
print(f"Extraction modes: {extraction_mode_counter.most_common()}")
print(f"Article distribution (top 10): {articles_counter.most_common(10)}")
print(f"Empty sections: {empty_sections}")
```

### Phase 2 — Targeted Defect Investigation

After the statistical audit, investigate each defect category.

**Garbled OCR headers:** Sample the `page_texts_sample` of files where the first page text contains known garbled patterns. For Arabic ADALA, the pattern is `((NN (مسيد` or `بمسيد` in the masthead.

**0-article files:** Check whether these files have `full_text_in_cache: true` and substantial content in their structure (preamble, titles, parts, books). If yes, they are legitimate non-article documents. If no, they are parser failures.

**Empty sections:** For each file with empty sections, examine the surrounding structure to understand if the content is in a sibling or truly missing.

### Phase 3 — Repair

#### Repair 1: Garbled OCR Masthead

Write a targeted repair script that:
1. Detects the garbled masthead pattern via regex
2. Extracts the issue number from the garbled text
3. Replaces the garbled masthead with a clean version: `الجريدة الرسمية العدد NNNN`

```python
import re

GARBLED_PATTERNS = [
    re.compile(r'\(\(\d+\s*\(مسيد.*?عدد\s*(\d+)\s*الجريدة\s*الرسمية', re.DOTALL),
    re.compile(r'\(\(\d+\s*\(1\s*بمسيد.*?عدد\s*(\d+)\s*الجريدة\s*الرسمية', re.DOTALL),
    re.compile(r'\(\(\d+\s*\(مسيد.*?عدد\s*(\d+).*?\n\s*الجريدة\s*الرسمية', re.DOTALL),
]

def repair_masthead(text: str) -> tuple[str, bool]:
    for pattern in GARBLED_PATTERNS:
        m = pattern.search(text)
        if m:
            issue_number = m.group(1)
            clean_masthead = f"الجريدة الرسمية العدد {issue_number}"
            replacement = re.compile(r'\(\(\d+[^ن]*?عدد\s*\d+\s*(?:الجريدة\s*الرسمية|[^\n]*?\n\s*الجريدة\s*الرسمية)', re.DOTALL)
            cleaned = replacement.sub(clean_masthead, text, count=1)
            if cleaned != text:
                return cleaned, True
    
    if 'الجريدة الرسمية' in text and 'مسيد' in text:
        fixed = re.sub(r'^الجريدة\s*الرسمية\s+(\d+)', r'الجريدة الرسمية العدد \1', text, count=1)
        fixed = re.sub(r'\n\(\(\d+[^\n]*?\n', '\n', fixed, count=1)
        if fixed != text:
            return fixed, True
    
    return text, False
```

#### Repair 2: Add Metadata Flags

Add `has_article_structure` flag to every JSON file. This tells downstream search/RAG whether article-level chunking is available:

```python
def has_articles(structure) -> bool:
    if not structure:
        return False
    for item in structure:
        if item.get("type") == "article":
            return True
        if item.get("children"):
            if has_articles(item["children"]):
                return True
    return False

data["has_article_structure"] = has_articles(data.get("structure", []))
```

Also add the flag to the parser output dict in `pipeline.py` so it's set on every future parse:

```python
"has_article_structure": bool(structure_node_count({"type": "article"}, root, tree=True)),
```

The `structure_node_count` helper (in `pipeline_base/structure.py`) counts nodes of a given type recursively in the tree.

#### Repair 3: Fix Empty Sections

Merge empty section titles into the next sibling with content:

```python
def fix_empty_sections(structure) -> tuple[list, int]:
    if not structure:
        return structure, 0
    
    fixed = []
    pending_empty_title = None
    num_fixed = 0
    
    for item in structure:
        if item.get("type") == "section":
            content = item.get("content", "")
            if not content or not content.strip():
                title = item.get("title", "")
                if title:
                    pending_empty_title = f"{pending_empty_title} — {title}" if pending_empty_title else title
                continue
            else:
                if pending_empty_title:
                    existing = item.get("content", "")
                    item["content"] = f"{pending_empty_title}: {existing}"
                    pending_empty_title = None
                    num_fixed += 1
                
                if item.get("children"):
                    fixed_children, child_fixes = fix_empty_sections(item["children"])
                    item["children"] = fixed_children
                    num_fixed += child_fixes
                
                fixed.append(item)
        else:
            if pending_empty_title:
                pending_empty_title = None
            
            if item.get("children"):
                fixed_children, child_fixes = fix_empty_sections(item["children"])
                item["children"] = fixed_children
                num_fixed += child_fixes
            
            fixed.append(item)
    
    return fixed, num_fixed
```

### Phase 4 — Verify

Re-run the same audit metrics after repair. Confirm:
- Garbled files: 0
- Empty sections: 0
- All files have `has_article_structure` flag

### Phase 5 — Test

Run the relevant test suite to confirm no regressions:

```bash
cd /home/mohammed/Mizan
/home/mohammed/Mizan/venv/bin/pytest tests/test_adala_metadata_defects.py tests/test_adala_vision_structure.py tests/test_adala_relationships.py -v --tb=short
```

## Pitfalls

- **Re-OCRing documents with clean body text** — wastes compute and risks new errors. Targeted masthead repair is the correct fix for garbled headers with clean body.
- **Classifying draft laws as defects** — مشروع قانون المالية (draft finance laws) organized by parts/titles are structurally valid without numbered articles. Check `full_text_in_cache` and structure content before classifying.
- **Regex too strict on garbled patterns** — OCR garbling is not consistent. Start with flexible patterns (.*?) and tighten only if false positives appear. The 2016 variant had the masthead on a separate line BEFORE the garbled text — handle that case explicitly.
- **Not recursing into children** — empty sections and article counts must be checked recursively in the structure tree. A flat iteration misses nested sections.
- **Fixing without verifying** — always re-run the audit after repair. A fix that doesn't change the metric is not a fix.
- **Losing metadata on re-parsing** — when fixing in place, the JSON's timestamp, extraction_mode, source_url are preserved. Re-parsing from PDF loses these.
- **Only fixing the JSON, not the parser** — in-place repair fixes the current corpus but a future re-parse re-introduces the defect. When the user wants a complete valid corpus, fix the parser too and re-parse. When only the current corpus needs cleaning, in-place repair is enough.
- **Async generator consumed twice** — when adding masthead repair to `pipeline.py`, the `pages` value from `extract_pages()` is an async generator. Collect it into a list first (`pages_list = [p or "" for p in pages]`), then run the masthead repair loop on the list. Iterating the generator to build `sample_text` and then again for repair fails because the generator is already exhausted.
- **Container detection too loose** — `_container_hit()` with a fuzzy position window (pos ≤ 25) catches body text that merely mentions a section keyword (e.g. `-كلغ 200 من القسم الأول...`). Tighten to anchored regex first, then fuzzy fallback with pos ≤ 5 only. Test with the specific false-positive lines from the corpus before widening.
