---
# OCR Masthead Repair — Arabic ADALA Official Journal Headers

## Problem

Arabic ADALA PDFs sometimes have garbled OCR output on the official journal masthead line. The masthead `الجريدة الرسمية العدد NNNN` ( Official Gazette issue NNNN) gets corrupted while the body text remains clean.

## Garbling Patterns Observed

### Pattern 1: Standard garbled masthead (single line)
```
((19 (مسيد 91(1( 17 ج 1 خالا يدامج 717 - 7362 عدد 9754 الجريدة الرسمية
```
Decodes to: `الجريدة الرسمية العدد 9754`

### Pattern 2: "بمسيد" prefix variant
```
((16 (1 بمسيد 6(1( 225 ج 2 خالا يدامج 525 - 476 57465 عدد 9648 الجريدة الرسمية
```
Decodes to: `الجريدة الرسمية العدد 9648`

### Pattern 3: Multi-line (number and masthead on separate lines)
```
((23 (مسيد 32(2( 28 ج 2 وألا يدامج 828 - 45177154 عدد
الجريدة الرسمية
```
Decodes to: `الجريدة الرسمية العدد 11380`

### Pattern 4: Masthead on first line, garbled text on second line (2016 variant)
```
الجريدة الرسمية 10081
((21 (مسيد 12(2( 9 رب 9 وألا عيبر 9 - 6423 عدد
```
Decodes to: `الجريدة الرسمية العدد 10081` (and remove the garbled second line)

### Pattern 5: Lowercase "رب" instead of "ج" (article ordinal variant)
```
((21 (مسيد 12(2( 9 رب 9 وألا عيبر 9 - 6423 عدد 10081 الجريدة الرسمية
```
The ordinal marker can be `رب` (رَبْع/ربع) instead of `ج` (جُزْء/جزء) depending on the PDF's OCR output. The repair regex must not anchor on either one specifically — use `.?` to match any single Arabic character in that slot.

## Repair Strategy

1. **Detect** the garbled pattern via regex
2. **Extract** the issue number (the 5-digit number before `الجريدة الرسمية`)
3. **Replace** the entire garbled block with `الجريدة الرسمية العدد NNNN`

## Regex Patterns (Python)

```python
import re

GARBLED_PATTERNS = [
    # Pattern 1: standard single-line
    re.compile(r'\(\(\d+\s*\(مسيد.*?عدد\s*(\d+)\s*الجريدة\s*الرسمية', re.DOTALL),
    # Pattern 2: "بمسيد" prefix
    re.compile(r'\(\(\d+\s*\(1\s*بمعيد.*?عدد\s*(\d+)\s*الجريدة\s*الرسمية', re.DOTALL),
    # Pattern 3: multi-line
    re.compile(r'\(\(\d+\s*\(مسيد.*?عدد\s*(\d+).*?\n\s*الجريدة\s*الرسمية', re.DOTALL),
]

def repair_masthead(text: str) -> tuple[str, bool]:
    for pattern in GARBLED_PATTERNS:
        m = pattern.search(text)
        if m:
            issue_number = m.group(1)
            clean_masthead = f"الجريدة الرسمية العدد {issue_number}"
            replacement = re.compile(
                r'\(\(\d+[^ن]*?عدد\s*\d+\s*(?:الجريدة\s*الرسمية|[^\n]*?\n\s*الجريدة\s*الرسمية)',
                re.DOTALL
            )
            cleaned = replacement.sub(clean_masthead, text, count=1)
            if cleaned != text:
                return cleaned, True
    
    # Pattern 4: masthead on first line, garbled on second
    if 'الجريدة الرسمية' in text and 'مسيد' in text:
        fixed = re.sub(
            r'^الجريدة\s*الرسمية\s+(\d+)',
            r'الجريدة الرسمية العدد \1',
            text, count=1
        )
        fixed = re.sub(r'\n\(\(\d+[^\n]*?\n', '\n', fixed, count=1)
        if fixed != text:
            return fixed, True
    
    return text, False
```

## Key Insight

The issue number is always preserved correctly in the garbled output — it's the surrounding masthead text that gets corrupted. The repair extracts the issue number and reconstructs a clean masthead. No need to re-OCR the entire document.

## When NOT to Use This

- If the body text is also garbled, re-OCR is needed
- If the issue number itself is unreadable, manual investigation is required
- If the PDF has no text layer at all (pure image scan), use full OCR pipeline
